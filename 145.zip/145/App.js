<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://aframe.io/releases/1.0.4/aframe.min.js"></script>
   
    <title>Document</title>
</head>
<body>
    <a-scene>
        <a-box position="-2 0.5 -5" rotation="0 3 0" color="blue"></a-box>
        <a-cylinder position="0 0.5 -5" radius="0.5" height="1" color="green"></a-cylinder>
        <a-sphere position="2 0.5 -5" radius="0.5" color="red"></a-sphere>
        <a-cone position="4 0.5 -5" radius="0.5" height="2" color="yellow" ></a-cone>
        <a-octahedron position="-4 0.5 -5" color="purple" radius="0.45"></a-octahedron>
        <a-ring position="-6 0.5 -5" color="teal" radius-inner="0.25" radius-outer="0.7"></a-ring>

    </a-scene>
</body>
</html>